<?php
/* @var $this yii\web\View */
$this->title = Yii::$app->name;
?>
<div class="starter-template">
    <h1>Bootstrap starter template</h1>
    <p class="lead">Use this document as a way to quickly start any new project.<br> All you get is this text and a
        mostly barebones HTML document.</p>
</div>