<?php

namespace api\controllers;

class DataController extends ApiController
{

    public function actionIndex()
    {
        $this->msg = 'Data Controller';
    }
}
